
public class SumOfTwoNumbers {
	public static void main(String args[]) {
		System.out.println(Integer.parseInt(args[0]) + Integer.parseInt(args[1]));
	}
}
